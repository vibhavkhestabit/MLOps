--
-- PostgreSQL database cluster dump
--

\restrict JoHXUihhoDR8ZqO4r1pveZ7QcrTNN10YNsKQ6GbqUw25QddYTJMzfbleAxoGAkI

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE dbadmin;
ALTER ROLE dbadmin WITH SUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:F08gpJmqTGItte/FSJoIbQ==$xVHatjKDCacVXyrvOS89U+1QoLK6HSa/QCfDd7eE3vY=:pI7hSes1Q2VWDKPJ2v6d2V65XDyJYTjwGGn8+/Ytw9Q=';
CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS;
CREATE ROLE testing;
ALTER ROLE testing WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:1zSOCP2k9GXMvMKtjb2J8g==$rbiymE8qwu3h/3x4mHmpcxKu8WWvTZQWvea4yIAY3Kc=:EhlTfDpqajrxjyeXasFh9czFYnqOa90SKfAvAHOL/8E=';

--
-- User Configurations
--








\unrestrict JoHXUihhoDR8ZqO4r1pveZ7QcrTNN10YNsKQ6GbqUw25QddYTJMzfbleAxoGAkI

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict h2zRIPPe6CzXiypOThMGSz5iBcYHjk3HcNSLzZ8oAEfRNpjaCdi0SOMpOWlMvZA

-- Dumped from database version 15.17 (Ubuntu 15.17-1.pgdg24.04+1)
-- Dumped by pg_dump version 15.17 (Ubuntu 15.17-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict h2zRIPPe6CzXiypOThMGSz5iBcYHjk3HcNSLzZ8oAEfRNpjaCdi0SOMpOWlMvZA

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict MEzQfjSJWmgqIAzTLk3pNi4wVcaks7zhdLdO74uak6z1viMPzmqDpXaaeGrIjzL

-- Dumped from database version 15.17 (Ubuntu 15.17-1.pgdg24.04+1)
-- Dumped by pg_dump version 15.17 (Ubuntu 15.17-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict MEzQfjSJWmgqIAzTLk3pNi4wVcaks7zhdLdO74uak6z1viMPzmqDpXaaeGrIjzL

--
-- Database "testdb" dump
--

--
-- PostgreSQL database dump
--

\restrict xtcfceZeu3jUQz98ochdRzSMSFunKPGEYKatiykF2uzSWQ0KqpxuugiXNsBHLdz

-- Dumped from database version 15.17 (Ubuntu 15.17-1.pgdg24.04+1)
-- Dumped by pg_dump version 15.17 (Ubuntu 15.17-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: testdb; Type: DATABASE; Schema: -; Owner: dbadmin
--

CREATE DATABASE testdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE testdb OWNER TO dbadmin;

\unrestrict xtcfceZeu3jUQz98ochdRzSMSFunKPGEYKatiykF2uzSWQ0KqpxuugiXNsBHLdz
\connect testdb
\restrict xtcfceZeu3jUQz98ochdRzSMSFunKPGEYKatiykF2uzSWQ0KqpxuugiXNsBHLdz

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict xtcfceZeu3jUQz98ochdRzSMSFunKPGEYKatiykF2uzSWQ0KqpxuugiXNsBHLdz

--
-- PostgreSQL database cluster dump complete
--

