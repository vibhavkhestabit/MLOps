--
-- PostgreSQL database cluster dump
--

\restrict QgvkXliGmHU7QbBreaQ9Cx7Em4pvXruZUBOMNQtmTd1Ejx6N8kqyPGncRCtdhob

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE dbadmin;
ALTER ROLE dbadmin WITH SUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:F08gpJmqTGItte/FSJoIbQ==$xVHatjKDCacVXyrvOS89U+1QoLK6HSa/QCfDd7eE3vY=:pI7hSes1Q2VWDKPJ2v6d2V65XDyJYTjwGGn8+/Ytw9Q=';
CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS;
CREATE ROLE testing;
ALTER ROLE testing WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:1zSOCP2k9GXMvMKtjb2J8g==$rbiymE8qwu3h/3x4mHmpcxKu8WWvTZQWvea4yIAY3Kc=:EhlTfDpqajrxjyeXasFh9czFYnqOa90SKfAvAHOL/8E=';

--
-- User Configurations
--








\unrestrict QgvkXliGmHU7QbBreaQ9Cx7Em4pvXruZUBOMNQtmTd1Ejx6N8kqyPGncRCtdhob

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict tEdeFypQAlaBaO4GDUQ5MQpIhvpDjlEdBRC1hY6T9ID0oZtd25g1Ho0ut47k9Om

-- Dumped from database version 15.17 (Ubuntu 15.17-1.pgdg24.04+1)
-- Dumped by pg_dump version 15.17 (Ubuntu 15.17-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict tEdeFypQAlaBaO4GDUQ5MQpIhvpDjlEdBRC1hY6T9ID0oZtd25g1Ho0ut47k9Om

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict 5DiQuPoxtWGg3dg5F6vjzzYF6ldHWCxsCgABDpII3hKEnrgFs0tvCXYzx8L8otN

-- Dumped from database version 15.17 (Ubuntu 15.17-1.pgdg24.04+1)
-- Dumped by pg_dump version 15.17 (Ubuntu 15.17-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict 5DiQuPoxtWGg3dg5F6vjzzYF6ldHWCxsCgABDpII3hKEnrgFs0tvCXYzx8L8otN

--
-- Database "testdb" dump
--

--
-- PostgreSQL database dump
--

\restrict lzjZt9SHChCrHD6ogKcsX3Z6nSeXKzmmru2uMzPmdHwco8VQ8YJFVUPQU0MURPX

-- Dumped from database version 15.17 (Ubuntu 15.17-1.pgdg24.04+1)
-- Dumped by pg_dump version 15.17 (Ubuntu 15.17-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: testdb; Type: DATABASE; Schema: -; Owner: dbadmin
--

CREATE DATABASE testdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE testdb OWNER TO dbadmin;

\unrestrict lzjZt9SHChCrHD6ogKcsX3Z6nSeXKzmmru2uMzPmdHwco8VQ8YJFVUPQU0MURPX
\connect testdb
\restrict lzjZt9SHChCrHD6ogKcsX3Z6nSeXKzmmru2uMzPmdHwco8VQ8YJFVUPQU0MURPX

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict lzjZt9SHChCrHD6ogKcsX3Z6nSeXKzmmru2uMzPmdHwco8VQ8YJFVUPQU0MURPX

--
-- PostgreSQL database cluster dump complete
--

